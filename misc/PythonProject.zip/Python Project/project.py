import arcpy

arcpy.env.workspace = arcpy.GetParameterAsText(0)

file_list = arcpy.ListFeatureClasses()

projection = arcpy.GetParameterAsText(1)
clipping_feature = arcpy.GetParameterAsText(2)

geodatabase_name = arcpy.GetParameterAsText(3)
if arcpy.Exists(arcpy.env.workspace + "\\" + geodatabase_name + ".gdb"):
    arcpy.management.Delete(arcpy.env.workspace + "\\" + geodatabase_name + ".gdb")

if arcpy.env.workspace[-4:] == ".gdb":
	arcpy.management.CreateFileGDB(arcpy.env.workspace + "\\" + ".." + "\\",geodatabase_name)
else:
	arcpy.management.CreateFileGDB(arcpy.env.workspace,geodatabase_name)

files_to_import = []
files_to_delete = []

for f in file_list:
	if f[-4:] == ".shp":
		g = f.replace(".shp","_proj.shp")
		h = f.replace(".shp","_final.shp")
	else:
		g = f + "_proj"
		h = f + "_final"
	arcpy.management.Project(f,g,projection)
	arcpy.analysis.Clip(g,clipping_feature,h)
	files_to_import.append(h)
	files_to_delete.append(g)
	files_to_delete.append(h)
    
if arcpy.env.workspace[-4:] == ".gdb":
	arcpy.conversion.FeatureClassToGeodatabase(files_to_import,arcpy.env.workspace + "\\" +  ".." + "\\" + geodatabase_name + ".gdb")
else:
	arcpy.conversion.FeatureClassToGeodatabase(files_to_import,arcpy.env.workspace + "\\" + geodatabase_name + ".gdb")

for f in files_to_delete:	
    arcpy.management.Delete(f)
